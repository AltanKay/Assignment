INSERT INTO Sales (OrderID, Product, Price, Quantity, OrderDate) VALUES (1, 'Pen', 2.99, 2, '2024-12-25');
INSERT INTO Sales (OrderID, Product, Price, Quantity, OrderDate) VALUES (2, 'Pencil', 1.99, 5, '2024-12-26');
INSERT INTO Sales (OrderID, Product, Price, Quantity, OrderDate) VALUES (3, 'Stilo', 3.99, 3, '2024-12-27');
INSERT INTO Sales (OrderID, Product, Price, Quantity, OrderDate) VALUES (4, 'Eraser', 0.99, 10, '2024-12-28');
INSERT INTO Sales (OrderID, Product, Price, Quantity, OrderDate) VALUES (5, 'Sharpener', 0.99, 7, '2024-12-29');
