msg = "Hello! Roll a dice!"
print(msg)

x = "quantity"
x = 5
y = "price"
y = 200
z = "multiply"
z = x * y
print(z)