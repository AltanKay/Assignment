my_list = ["Pen",'Pencil',"Eraser", "Stilo", "Sharpener"]
for x in my_list:
    print(x)