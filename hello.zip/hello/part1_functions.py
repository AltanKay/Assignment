def calculate_revenue(price, quantity):
    return price * quantity
print(calculate_revenue(300,7))